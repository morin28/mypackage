# mypackage
This library was created as an example of how to publish python package

## building this package locally
`Python setup.py sdist`

## installing this package from Github
`pip install git+`

## updating this package from Github
`pip install --upgrade git+`
